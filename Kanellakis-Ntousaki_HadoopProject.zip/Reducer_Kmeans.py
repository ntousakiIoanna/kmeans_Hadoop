#!/usr/bin/python
"""reducer.py"""

'''
@authors:KosmasKanellakis t8200053, IoannaNtousaki t8200125
'''

import sys
def reducer():
    # variable center refers initially to no center =>> center = 0, 1, 2 etc
    center = -1
    sumX = 0
    sumY = 0
    countPointsForEachCenter = 0
    for line in sys.stdin:
        # A table containing line-data extracted from mapping procedure sorted by index through Hadoop shuffle
        # mapper_data = [index, x_coordinate, y_coordinate]
        mapper_data = [float(y) for y in line.strip().split('\t')]
        
        # the point has the same center as the previous ones
        if center == mapper_data[0]:
            
            # add the coordinates of the new point to the sum
            countPointsForEachCenter += 1 
            sumX += mapper_data[1]
            sumY += mapper_data[2]
        
        # the point has a new index as a center  
        else:
            
            if countPointsForEachCenter != 0 :
                
                #   calculate the coordinates of the new center
                print(str(sumX / countPointsForEachCenter) + ", " + str(sumY / countPointsForEachCenter))
            
            #   start counting values for the new center
            countPointsForEachCenter = 1
            #   mapper_data[0] only takes sorted values that are incremented one at a time starting from zero
            #   so, the new center's value will just be increased by 1
            center += 1
            sumX = mapper_data[1]
            sumY = mapper_data[2]
            
    #   print the coordinates of the last center found    
    if countPointsForEachCenter != 0 :
        print(str(sumX / countPointsForEachCenter) + ", " + str(sumY / countPointsForEachCenter))
    
 
if __name__ == '__main__':
    reducer()
    