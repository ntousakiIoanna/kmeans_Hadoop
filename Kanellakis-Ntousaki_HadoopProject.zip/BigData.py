'''
@authors:KosmasKanellakis t8200053, IoannaNtousaki t8200125
'''

from scipy.stats import skewnorm
import random
import math
import pandas as pd
import matplotlib.pyplot as plt 

# define the centers of the three clusters
center1 = (10, 25)
center2 = (2, -9)
center3 = (-15, -35)

# define the number of points that will be created 
num_Of_points = 1000000

# higher skewness tighter clustering around center points
# lower skewness more spread-out around center points
skewness = 2 

# create a table of size = num_Of_points with random distance values 
# following skewed distribution
distance = skewnorm.rvs(skewness, size = num_Of_points)

# create a file to store the data
with open("centers.txt", "w") as f:
    # write the coordinates of the three centers to the file
    f.write(f"{center1[0]},{center1[1]}\n")
    f.write(f"{center2[0]},{center2[1]}\n")
    f.write(f"{center3[0]},{center3[1]}\n")

# generate the remaining data points around the three centers
array = []
for i in range(num_Of_points):
    while True:
        # choose a random center (weighted towards the three centers)
        r = random.random()
        if r < 0.33:
            center = center1
        elif r < 0.66:
            center = center2
        else:
            center = center3

        # generate the angle of the data point (uniformly distributed)
        angle = random.uniform(0, 2*math.pi)
        
        # convert the polar coordinates to cartesian coordinates
        x = center[0] + distance[i] * math.cos(angle)
        y = center[1] + distance[i] * math.sin(angle)
        
        # add the point to the array only if it hasn't been inserted already 
        # if it already exists, just ignore it   
        if [x, y, center] not in array:

                break 
                
    array.append([x, y, center])
        

# write the coordinates to a file
df = pd.DataFrame(array)
df.drop(df.columns[[2]], axis=1, inplace=True)
df.to_csv("data.txt", header=False, index= False, sep="," )

