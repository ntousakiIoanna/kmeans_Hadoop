import Mapper_Kmeans 

'''
@authors:KosmasKanellakis t8200053, IoannaNtousaki t8200125
'''

#   if distance of centers and centers1 is less than 1, then it is concidered negligible
def checkCentersDistance(centers, centers1):
    x1 = abs(centers[0][0] - centers1[0][0])<1
    y1 = abs(centers[0][1] - centers1[0][1])<1
    x2 = abs(centers[1][0] - centers1[1][0])<1
    y2 = abs(centers[1][1] - centers1[1][1])<1
    x3 = abs(centers[2][0] - centers1[2][0])<1
    y3 = abs(centers[2][1] - centers1[2][1])<1

# when all distances are approximately equal to 0  the algorithm returns 1 and stops
    if x1 and y1 and x2 and y2 and x3 and y3 :
        print(1)
    else:
        print(0)

if __name__ == "__main__":
    centers = Mapper_Kmeans.getCenters('centers.txt')
    centers1 = Mapper_Kmeans.getCenters('centers1.txt')
    
    checkCentersDistance(centers, centers1)