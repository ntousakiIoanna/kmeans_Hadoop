#!/bin/bash
#@authors Kosmas Kanellakis t8200053, Ioanna Ntousaki t8200125
i=1
while :
do
	hadoop jar C:\Necessary\hadoop-3.2.4\share\hadoop\share\tools\lib\hadoop-streaming-3.2.4.jar -file centers.txt -mapper "python ./Mapper_Kmeans.py" -reducer "python ./Reducer_Kmeans.py" -input /testMapReduce/data.txt -output /testMapReduceOut/mapreduce-output$i
	rm -f centers1.txt
	hadoop fs -copyToLocal /testMapReduceOut/mapreduce-output$i/part-00000 centers1.txt
	seeiftrue=`python3 checker.py`
	echo $seeiftrue
	if [ $seeiftrue = 1 ]
	then
		rm centers.txt
		hadoop fs -copyToLocal /testMapReduceOut/mapreduce-output$i/part-00000 centers.txt
		break
	else
		rm centers.txt
		hadoop fs -copyToLocal /testMapReduceOut/mapreduce-output$i/part-00000 centers.txt
	fi
	i=$((i+1))
done