#!/usr/bin/python
"""mapper.py"""

'''
@authors:KosmasKanellakis t8200053, IoannaNtousaki t8200125
'''

import sys
import math
from scipy.spatial import distance

# get the centers given in the initial centers.txt file and store them in an array
def getCenters(filename):
    
    centers = []
    
    #read the file containing the 3 centers 
    with open(filename, 'r') as fname:
        lines = fname.readlines()
        centers = [[float(y) for y in x] for x in (line.strip().split(',') for line in lines[:])]
    fname.close()
    
    #return the table with the centers' coordinates
    return centers

#   map each point to the closest center creating clusters
def mapper(centers):
    for line in sys.stdin: 
        x, y = map(float, line.strip().split(','))
        
        closest_center_index = -1
        closest_center_distance = math.inf
        
        for center in centers:
            #   calculate the euclidean distance between the point and the current center
            distance = math.sqrt((x - center[0]) ** 2 + (y - center[1]) ** 2)
            #   check if the current center has less distance than the previous ones
            if distance < closest_center_distance:
                closest_center_index = centers.index(center)
                closest_center_distance = distance
        #   print the point coordinates along with its final center      
        print(f"{closest_center_index}\t{x}\t{y}")
    
if __name__ == '__main__':
    #   read the file containing the centers' coordinates and store them in the array centerCoords
    centersCoords = getCenters('centers.txt')
    #   create clusters using the centers' table 
    mapper(centersCoords)